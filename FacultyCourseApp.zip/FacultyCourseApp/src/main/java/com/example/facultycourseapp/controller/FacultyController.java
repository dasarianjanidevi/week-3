package com.example.facultycourseapp.controller;

import com.example.facultycourseapp.model.Faculty;
import com.example.facultycourseapp.service.FacultyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/faculty")
public class FacultyController {

    @Autowired
    private FacultyService facultyService;

    // Login API
    @PostMapping("/login")
    public String login(@RequestParam String email, @RequestParam String password) {
        Faculty faculty = facultyService.login(email, password);
        if (faculty != null) {
            return "Logged in successfully. Assigned Courses: " + faculty.getCourses();
        } else {
            return "Invalid credentials!";
        }
    }
}
