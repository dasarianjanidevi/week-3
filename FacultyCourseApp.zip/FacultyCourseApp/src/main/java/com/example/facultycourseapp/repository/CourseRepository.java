package com.example.facultycourseapp.repository;

import com.example.facultycourseapp.model.Course;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CourseRepository extends JpaRepository<Course, Long> {

    // Find course by its name
    List<Course> findByName(String name);

    // Find all courses with a specific duration
    List<Course> findByCourseDuration(String duration);

    // You can add more methods as needed
}
