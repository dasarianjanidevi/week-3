package com.example.facultycourseapp.repository;

import com.example.facultycourseapp.model.Faculty;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FacultyRepository extends JpaRepository<Faculty, Long> {
    // Custom query to find faculty by email and password for login
    Faculty findByEmailAndPassword(String email, String password);
}
