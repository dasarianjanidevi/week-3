package com.example.facultycourseapp.service;

import com.example.facultycourseapp.model.Faculty;
import com.example.facultycourseapp.repository.FacultyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FacultyService {

    @Autowired
    private FacultyRepository facultyRepository;

    // Business logic for login
    public Faculty login(String email, String password) {
        return facultyRepository.findByEmailAndPassword(email, password);
    }
}
